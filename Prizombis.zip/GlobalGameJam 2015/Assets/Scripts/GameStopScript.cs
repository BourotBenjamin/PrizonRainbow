﻿using UnityEngine;
using System.Collections;

public class GameStopScript : MonoBehaviour {

    public bool ended = false;

}
